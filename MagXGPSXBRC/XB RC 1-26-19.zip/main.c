/* ************************************************************************** */
/** Descriptive File Name:  main.c for Lab 7a. Generates one of eight single
                            frequency tones.

  @ Author
    Richard Wall
 
  @ Date
    Created;    February 6, 2018

  @Development Environment
    MPLAB X IDE x3.61 - http://www.microchip.com/mplab/mplab-x-ide 
	XC32 1.43 - http://www.microchip.com/mplab/compilers
	PLIB 3/7/20162 - http://www.microchip.com/SWLibraryWeb/product.aspx?product=PIC32%20Peripheral%20Library
  @File Name
    main.c

  @Summary
    The RCTC is not available on the Basys MX3 processor system

  @Description
   Continuously reads the PmodGPS and displays the available time and date on 
   the system LCD. Pressing BTNR, BTND, or BTNC will change the GPS sentence
   type. LED0 is toggles each time a new sentence is received from the GPS.
 
  @Remarks
    Reference:     PIC32MX2xx/4xx Users Manual - 
        http://ww1.microchip.com/downloads/en/DeviceDoc/61143H.pdf
    
    Uses XC32 peripheral library. See 
 http://ww1.microchip.com/downloads/en/DeviceDoc/32bitPeripheralLibraryGuide.pdf
 http://www.microchip.com/SWLibraryWeb/product.aspx?product=PIC32%20Peripheral%20Library
  
 ****   This application uses a peripheral bus clock set to 80MHz.  ****
    PBCLK set for 80 MHz, Set parameters in config_bits.h and hardware.h

 ******************************************************************************/

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: Included Files                                                    */
/* ************************************************************************** */

// System included files
#include "config_bits.h"
#include "hardware.h"
#include "main.h"
#include "Pot.h"
#include <plib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "MAG3110.h"
#include "i2c_lib.h"
#include "GPS_I2C.h"

// Platform common included files
#include "swDelay.h"

// Application included files
#include "uart4.h"  // Monitor UART
#include "uart2.h"  // GPS UART
#include "led7.h"
#include "LCDlib.h"
#include "RC.h"

int calc_ck_sum(char *str);
// Global variables
int gps_message = 0;        // Active GPS sentence 
extern int16_t led_value;
extern BOOL led_flag;

/* ************************************************************************** */
/* ************************************************************************** */
/* Section: File Scope or Global Data                                         */
/* ************************************************************************** */
/* ************************************************************************** */


/** 
  @Function
    int main( void ); 

  @Summary
    Initializes the hardware platform and performs the calculator operations.

  @Description
    System initialization and infinite application loop. Reads the GPS sentence 
    and decodes the sentence before displaying on the LCD. Also facilitates
    changing GPS sentences.

  @Precondition
    None

  @Parameters
    None

  @Returns
 The system has failed if the last statement is executed. 
      <li> EXIT_FAILURE (1)   Indicates an error occurred
      <li> EXIT_SUCCESS (0)   Indicates an error did not occur

  @Remarks
    See http://www.rhydolabz.com/documents/25/PMTK_A11.pdf and
    http://aprs.gids.nl/nmea/
 */

#define RC_CW   0   // RC Direction of rotation
#define RC_CCW  1

int main(void)
{
char lcdStr[20];
char ch2, ch4;              // Serial received character
BOOL rx2_flag, rx4_flag;    // Character ready flags
BOOL MagFlag = 0;
int I2CStep = 1;
I2C_RESULT I2cResultFlag;   // I2C Init Result flag
I2C_RESULT I2cReadFlag;     // I2C Read result flag
int dir = 0;                // RC rotation direction for sweep control
int pot;                    // Analog input for variable RC control
int rc_pos = 0;             // RC position
BYTE step = 1;              // RC loop update control

    Hardware_Setup();       // Initialize common IO
    uart4_init(38400, NO_PARITY);   // PC Terminal
    //uart2_init(9600, NO_PARITY);    // XBEE
    initLCD();              // Local real time display for Analog Input
    seg7_init();            // Displays seconds only
   
    I2cResultFlag = I2C_Init(I2C1, 100000); // Init I2c and GPS
   // MagFlag = MAG3110_initialize();

    //putsU2("\n\rXBee online\n\r");  // Send message to PC
    init_analog();          // Initialize AN2 to read Pot
    led_flag = 1;   // Enable 4 digit 7 segment LED display
    
    
    
    while(1)  // Forever process loop	
    {   
        
        if(((millisec % 10000) == 0))
        {
            if(I2CStep)
            {
                I2cReadFlag = ReportGPS(TRUE);
            }
            I2CStep = FALSE;    // Sets the step flag
            
         
        }
        else
        {
            I2CStep = TRUE; 
        }

        
        // Change RC position once each 100ms if SW1 or SW0 are set ons
        // This approach to non-blocking time delay allows concurrent real-
        // time processes.
        if(( (millisec % 100) == 0) && step ) 
        {
            // Since this background loop runs so fast, the "millisecond"
            // variable is seen as an 100ms interval multiple times. Hence
            // the variable "step" controls so that the RC updates only the 
            // first time it is detected.
            
            step = FALSE;   // Change RC only 1st time millisecond is read as modulo 100
            LATBbits.LATB8 = !PORTBbits.RB8;    //Toggle pin for timing test only - remove after testing
            if(!SW1() && !SW0()) // Check for not SW1 and not SW0
            {
                clrLCD();       // DIsplay RC operation mode on LCD
                sprintf(lcdStr,"RC Test");
                putsLCD(lcdStr);  
            }
            if(SW1() && !SW0()) // Check for SW1 and not SW0
            {
                clrLCD();       // DIsplay RC operation mode on LCD
                sprintf(lcdStr,"Sweep RC range");
                putsLCD(lcdStr);
                if(dir == RC_CW)    
                {
                    if(rc_pos < 100)
                    {
                        rc_pos++;       // Advance RC position by 1%
                    }
                    else
                    {
                        dir = RC_CCW;       // Reverse direction
                    } 
                }
                else
                {
                    if(dir == RC_CCW)
                    {
                        if(rc_pos >0 ) 
                        {
                            rc_pos--;       // RetardC position by 1%
                        }
                        else
                        {
                            dir = RC_CW;   // Reverse direction
                        }
                    }
                }
                set_rc(rc_pos,rc_pos,rc_pos,rc_pos); // Set all 4 RC channels
            }
            
            if(SW0() && !SW1()) // Check for SW0 and not SW1
            {
                clrLCD();                   // DIsplay RC operation mode on LCD
                sprintf(lcdStr,"Analog Control");
                putsLCD(lcdStr);
                pot = readAnalog(); // Read Analog input pot
                led_value = pot; // Update 4 digit 7 segment LED display
                rc_pos = (pot * 100) / 1024; // Convert to 0 - 100%
                set_rc(rc_pos,rc_pos,rc_pos,rc_pos);  // Set all 4 RC channels
            }
        }        
        else
        {
            step = TRUE;    // Set update flag for next 100ms period
        }
        
// Background process handles UART communications        
        rx2_flag = getcU2(&ch2);  // Poll for XBee character received
        if(rx2_flag)
        {
            putcU4(ch2);    // Send received character too both serial 
            putcU2(ch2);
        }        

        rx4_flag = getcU4(&ch4);  // Poll for UART character received
        if(rx4_flag)
        {
            putcU2(ch4);    // Send received character too both serial 
            putcU4(ch4);
        }    
    }
    
    return EXIT_FAILURE; // Code execution should never get to this statement 
}

