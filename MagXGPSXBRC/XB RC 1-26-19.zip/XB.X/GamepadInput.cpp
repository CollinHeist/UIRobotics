/* 
 * File:   GamepadInput.cpp
 * Author: Damon
 * 
 * Created on January 26, 2019, 3:10 PM
 */

#include "GamepadInput.h"

GamepadInput::GamepadInput() {
}

GamepadInput::GamepadInput(const GamepadInput& orig) {
}

GamepadInput::~GamepadInput() {
}

